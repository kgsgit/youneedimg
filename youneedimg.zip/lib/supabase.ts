import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://bmduyrsgjjwrpvmrrgut.supabase.co'
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJtZHV5cnNnamp3cnB2bXJyZ3V0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTEwMDA5MDIsImV4cCI6MjA2NjU3NjkwMn0.6_ZdyGatu9s7WA3JFNVSSfgpZOsAMr2jOuBTFYGKzFs'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)
