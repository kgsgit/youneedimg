// pages/index.tsx
import { GetServerSideProps } from "next";
import { createClient } from "@supabase/supabase-js";
import { useState } from "react";
import { onAuthStateChanged, signOut } from "firebase/auth";
import { auth } from "@/lib/firebase";
import { useRouter } from "next/router";

// 1) 서버 사이드용 Supabase Admin 클라이언트
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export type ImageItem = {
  name: string;
  url: string;
};

type Props = {
  images: ImageItem[];
};

export default function HomePage({ images }: Props) {
  const [user, setUser] = useState<any>(null);
  const [selectedImage, setSelectedImage] = useState<ImageItem | null>(null);
  const router = useRouter();

  // Firebase 로그인 상태 구독
  useState(() => {
    const unsub = onAuthStateChanged(auth, (u) => setUser(u));
    return () => unsub();
  });

  // 다운로드 핸들러
  const handleDownload = (url: string) => {
    if (!user) {
      router.push("/login");
      return;
    }
    const a = document.createElement("a");
    a.href = url;
    a.download = url.split("/").pop() || "image";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleLogout = async () => {
    await signOut(auth);
    setUser(null);
  };

  return (
    <div style={{ fontFamily: "sans-serif" }}>
      {/* Header */}
      <header style={{ background: "#f5f5f5", padding: "1rem 2rem", display: "flex", justifyContent: "space-between" }}>
        <h2 style={{ cursor: "pointer" }} onClick={() => router.push("/")}>
          youneedimg
        </h2>
        <nav>
          {user ? (
            <>
              <span style={{ marginRight: 16 }}>{user.email}</span>
              <button onClick={handleLogout}>로그아웃</button>
            </>
          ) : (
            <>
              <button onClick={() => router.push("/login")}>로그인</button>
              <button onClick={() => router.push("/signup")}>회원가입</button>
            </>
          )}
        </nav>
      </header>

      {/* Main */}
      <main style={{ padding: "2rem" }}>
        <h1>AI 일러스트</h1>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))",
            gap: "1.5rem",
          }}
        >
          {images.map((img) => {
            const filename = img.name.split("/").pop()!;
            return (
              <div
                key={img.name}
                style={{
                  border: "1px solid #ddd",
                  borderRadius: 8,
                  padding: "1rem",
                  textAlign: "center",
                  cursor: "pointer",
                }}
                onClick={() => setSelectedImage(img)}
              >
                <img
                  src={img.url}
                  alt={filename}
                  style={{ width: 150, height: 150, objectFit: "contain" }}
                />
                <p style={{ marginTop: 8 }}>{filename}</p>
                <button onClick={() => handleDownload(img.url)}>다운로드</button>
              </div>
            );
          })}
        </div>
      </main>

      {/* Modal */}
      {selectedImage && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0,0,0,0.6)",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
          onClick={() => setSelectedImage(null)}
        >
          <div
            style={{ background: "#fff", padding: "2rem", borderRadius: 8, maxWidth: "90vw" }}
            onClick={(e) => e.stopPropagation()}
          >
            <img
              src={selectedImage.url}
              alt={selectedImage.name}
              style={{ width: 300, height: 300, objectFit: "contain" }}
            />
            <p style={{ marginTop: 16 }}>{selectedImage.name.split("/").pop()}</p>
            <button onClick={() => handleDownload(selectedImage.url)}>다운로드</button>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer style={{ textAlign: "center", padding: "1rem", borderTop: "1px solid #ccc", color: "#777" }}>
        © {new Date().getFullYear()} youneedimg
      </footer>
    </div>
  );
}

// 2) SSR로 이미지 목록 가져오기
export const getServerSideProps: GetServerSideProps<Props> = async () => {
  // ① 루트 폴더 조회
  const { data: roots, error: rootErr } = await supabaseAdmin.storage
    .from("images")
    .list("", { limit: 100 });
  if (rootErr) throw rootErr;

  const paths: string[] = [];

  // ② 각 카테고리 폴더 내부 파일 수집
  for (const item of roots) {
    if (item.name.includes(".")) {
      paths.push(item.name);
    } else {
      const { data: files, error: filesErr } = await supabaseAdmin.storage
        .from("images")
        .list(item.name, { limit: 100 });
      if (!filesErr && files) {
        for (const f of files) {
          paths.push(`${item.name}/${f.name}`);
        }
      }
    }
  }

  // ③ publicUrl 생성
  const images = paths.map((p) => {
    const { data } = supabaseAdmin.storage.from("images").getPublicUrl(p);
    return { name: p, url: data.publicUrl };
  });

  return { props: { images } };
};
